export const initialState = {
  current: {},
  forecast: [],
  location: '',
  isLoading: true,
};
