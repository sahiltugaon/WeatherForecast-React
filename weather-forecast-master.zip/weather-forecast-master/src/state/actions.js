export const actions = {
  setForecast: 'SET_FORECAST',
};
